var datas = window.location.search;
var nDatas = "&" + datas.substr(1);
window.location.replace("http://hanpyo.com?c=0"+nDatas);
